#include "../header/udpserver.h"
#include "../header/Logger.h"
using namespace CPlusPlusLogging;

int main(){
 LOG_ALWAYS("<=============================== START OF PROGRAM ===============================>");
   // Log message using Direct Interface
   // Log Level: LOG_ERROR
   LOG_ERROR("Message Logged using Direct Interface, Log level: LOG_ERROR");
   LOG_ALARM("Message Logged using Direct Interface, Log level: LOG_ALARM");
   LOG_ALWAYS("Message Logged using Direct Interface, Log level: LOG_ALWAYS");
   LOG_INFO("Message Logged using Direct Interface, Log level: LOG_INFO");
   //LOG_BUFFER("Message Logged using Direct Interface, Log level: LOG_BUFFER");
   //LOG_TRACE("Message Logged using Direct Interface, Log level: LOG_TRACE");
   LOG_DEBUG("Message Logged using Direct Interface, Log level: LOG_DEBUG");
    udpServer server;
    server.~udpServer();


    return 0;
}
